const searchInput = document.getElementById('search-input');
const searchBtn = document.getElementById('search-btn');
const areaSelect = document.getElementById('area-select');
const dietSelect = document.getElementById('diet-select');
const randomBtn = document.getElementById('random-btn');
const mainContent = document.getElementById('main-content');
const loadingEl = document.getElementById('loading');
const errorMsgEl = document.getElementById('error-msg');

const tabSearch = document.getElementById('tab-search');
const tabFavorites = document.getElementById('tab-favorites');
const favCountEl = document.getElementById('fav-count');

const recipeModal = document.getElementById('recipe-modal');
const closeModal = document.getElementById('close-modal');
const modalDetails = document.getElementById('modal-details');

let favorites = JSON.parse(localStorage.getItem('favoriteRecipes')) || [];
let currentActiveTab = 'search';
let currentMealsCache = []; // Stores current raw list before local veg filtering

// Initialization sequence
initApp();

async function initApp() {
    await fetchWorldAreas();
    fetchInitialFeaturedDishes();
}

// Listeners
searchBtn.addEventListener('click', handleSearch);
searchInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') handleSearch();
});
areaSelect.addEventListener('change', handleAreaFilter);
dietSelect.addEventListener('change', applyDietFilter);
randomBtn.addEventListener('click', fetchRandomRecipe);

tabSearch.addEventListener('click', () => switchTab('search'));
tabFavorites.addEventListener('click', () => switchTab('favorites'));

closeModal.addEventListener('click', () => recipeModal.classList.add('hidden'));
window.addEventListener('click', (e) => {
    if (e.target === recipeModal) recipeModal.classList.add('hidden');
});

updateFavCount();

// --- API Functions ---

async function fetchWorldAreas() {
    try {
        const response = await fetch('https://www.themealdb.com/api/json/v1/1/list.php?a=list');
        const data = await response.json();
        if (data.meals) {
            data.meals.forEach(item => {
                const option = document.createElement('option');
                option.value = item.strArea;
                option.textContent = `${item.strArea} Cuisine`;
                areaSelect.appendChild(option);
            });
        }
    } catch (error) {
        console.error("Could not load world regions", error);
    }
}

async function fetchInitialFeaturedDishes() {
    showLoading(true);
    hideError();
    try {
        const response = await fetch('https://www.themealdb.com/api/json/v1/1/search.php?f=a');
        const data = await response.json();
        showLoading(false);
        if (data.meals) {
            currentMealsCache = data.meals;
            applyDietFilter();
        }
    } catch (error) {
        showLoading(false);
        showError("Could not load initial recipes.");
    }
}

async function handleSearch() {
    const query = searchInput.value.trim();
    if (!query) {
        showError("Please enter a search term.");
        return;
    }

    areaSelect.value = ""; 
    if (currentActiveTab !== 'search') switchTab('search');
    
    showLoading(true);
    hideError();

    try {
        const response = await fetch(`https://www.themealdb.com/api/json/v1/1/search.php?s=${query}`);
        const data = await response.json();
        showLoading(false);

        if (!data.meals) {
            showError(`No worldwide recipes found for "${query}".`);
            mainContent.innerHTML = '';
            return;
        }
        currentMealsCache = data.meals;
        applyDietFilter();
    } catch (error) {
        showLoading(false);
        showError("Failed to fetch recipes. Check your connection.");
    }
}

async function handleAreaFilter() {
    const selectedArea = areaSelect.value;
    if (!selectedArea) {
        fetchInitialFeaturedDishes();
        return;
    }

    searchInput.value = ""; 
    if (currentActiveTab !== 'search') switchTab('search');

    showLoading(true);
    hideError();

    try {
        const response = await fetch(`https://www.themealdb.com/api/json/v1/1/filter.php?a=${selectedArea}`);
        const data = await response.json();
        showLoading(false);

        if (!data.meals) {
            showError(`No recipes found for ${selectedArea} cuisine.`);
            mainContent.innerHTML = '';
            return;
        }
        
        // TheMealDB filter.php only returns summary elements (id, name, thumb). We fetch details or treat categories appropriately.
        // Let's grab full details for these meals so we can evaluate categories (Vegetarian vs Non-Veg).
        const detailedMeals = await Promise.all(
            data.meals.map(async (m) => {
                const res = await fetch(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${m.idMeal}`);
                const detailData = await res.json();
                return detailData.meals ? detailData.meals[0] : null;
            })
        );
        
        currentMealsCache = detailedMeals.filter(Boolean);
        applyDietFilter();
    } catch (error) {
        showLoading(false);
        showError("Failed to fetch regional recipes.");
    }
}

function applyDietFilter() {
    const diet = dietSelect.value;
    let filtered = currentMealsCache;

    if (diet === 'veg') {
        filtered = currentMealsCache.filter(meal => 
            meal.strCategory && meal.strCategory.toLowerCase() === 'vegetarian'
        );
    } else if (diet === 'non-veg') {
        filtered = currentMealsCache.filter(meal => 
            meal.strCategory && meal.strCategory.toLowerCase() !== 'vegetarian'
        );
    }

    let title = "Featured Worldwide Dishes";
    if (areaSelect.value) title = `${areaSelect.value} Cuisine Specialties`;
    if (searchInput.value.trim()) title = `Search Results for "${searchInput.value.trim()}"`;

    if (filtered.length === 0) {
        mainContent.innerHTML = '';
        showError(`No ${diet === 'veg' ? 'Vegetarian' : 'Non-Vegetarian'} recipes found in this view.`);
        return;
    }

    hideError();
    displayRecipes(filtered, title);
}

async function fetchRandomRecipe() {
    if (currentActiveTab !== 'search') switchTab('search');
    showLoading(true);
    hideError();

    try {
        const response = await fetch('https://www.themealdb.com/api/json/v1/1/random.php');
        const data = await response.json();
        showLoading(false);
        if (data.meals) {
            openRecipeModal(data.meals[0]);
        }
    } catch (error) {
        showLoading(false);
        showError("Failed to fetch a random recipe.");
    }
}

function displayRecipes(meals, title = "") {
    mainContent.innerHTML = '';
    
    if (title) {
        const banner = document.createElement('div');
        banner.className = 'grid-banner';
        banner.textContent = title;
        mainContent.appendChild(banner);
    }

    const grid = document.createElement('div');
    grid.className = 'recipe-grid';

    meals.forEach(meal => {
        const isFav = favorites.some(fav => fav.idMeal === meal.idMeal);
        const card = document.createElement('div');
        card.className = 'recipe-card';
        card.innerHTML = `
            <img src="${meal.strMealThumb}" alt="${meal.strMeal}">
            <div class="card-body">
                <div>
                    <h3>${meal.strMeal}</h3>
                    <div class="meta-tags">
                        <span class="tag">${meal.strCategory || 'Global'}</span>
                        <span class="tag">${meal.strArea || areaSelect.value || 'World'}</span>
                    </div>
                </div>
                <div class="card-actions">
                    <button onclick="fetchRecipeDetails('${meal.idMeal}')">View Recipe</button>
                    <button class="fav-action-btn ${isFav ? 'active' : ''}" onclick='toggleFavorite(${JSON.stringify(meal).replace(/'/g, "&#39;")})'>
                        <i class="fa-solid fa-bookmark"></i>
                    </button>
                </div>
            </div>
        `;
        grid.appendChild(card);
    });

    mainContent.appendChild(grid);
}

async function fetchRecipeDetails(id) {
    showLoading(true);
    try {
        const response = await fetch(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${id}`);
        const data = await response.json();
        showLoading(false);
        if (data.meals) {
            openRecipeModal(data.meals[0]);
        }
    } catch (error) {
        showLoading(false);
        showError("Could not load details.");
    }
}

function openRecipeModal(meal) {
    const ingredients = [];
    for (let i = 1; i <= 20; i++) {
        if (meal[`strIngredient${i}`]) {
            ingredients.push(`${meal[`strIngredient${i}`]} — ${meal[`strMeasure${i}`]}`);
        } else {
            break;
        }
    }

    const isFav = favorites.some(fav => fav.idMeal === meal.idMeal);

    modalDetails.innerHTML = `
        <div class="modal-header-flex">
            <img src="${meal.strMealThumb}" alt="${meal.strMeal}">
            <div class="modal-title-area">
                <h2>${meal.strMeal}</h2>
                <div class="meta-tags" style="margin-bottom: 12px;">
                    <span class="tag">${meal.strCategory}</span>
                    <span class="tag">${meal.strArea}</span>
                </div>
                <button class="outline-btn" style="padding: 6px 12px; font-size: 0.8rem;" onclick='toggleFavoriteFromModal(${JSON.stringify(meal).replace(/'/g, "&#39;")})'>
                    <i class="fa-solid fa-bookmark"></i> ${isFav ? 'Saved' : 'Save Recipe'}
                </button>
            </div>
        </div>
        <div>
            <div class="recipe-section-title">Ingredients</div>
            <ul class="ingredients-checklist">
                ${ingredients.map(ing => `<li>${ing}</li>`).join('')}
            </ul>
            <div class="recipe-section-title">Instructions</div>
            <p class="instruction-text">${meal.strInstructions}</p>
        </div>
        <div class="modal-action-bar">
            ${meal.strYoutube ? `<button class="secondary-action" onclick="window.open('${meal.strYoutube}', '_blank')"><i class="fa-brands fa-youtube"></i> Watch Tutorial</button>` : ''}
            <button class="secondary-action" onclick='copyIngredients(${JSON.stringify(ingredients)})'><i class="fa-solid fa-copy"></i> Copy Ingredients</button>
        </div>
    `;

    recipeModal.classList.remove('hidden');
}

function toggleFavorite(meal) {
    const index = favorites.findIndex(fav => fav.idMeal === meal.idMeal);
    if (index > -1) {
        favorites.splice(index, 1);
    } else {
        favorites.push(meal);
    }
    localStorage.setItem('favoriteRecipes', JSON.stringify(favorites));
    updateFavCount();

    if (currentActiveTab === 'favorites') {
        renderFavorites();
    } else {
        applyDietFilter();
    }
}

function toggleFavoriteFromModal(meal) {
    toggleFavorite(meal);
    fetchRecipeDetails(meal.idMeal);
}

function updateFavCount() {
    favCountEl.textContent = favorites.length;
}

function switchTab(tab) {
    currentActiveTab = tab;
    if (tab === 'search') {
        tabSearch.classList.add('active');
        tabFavorites.classList.remove('active');
        applyDietFilter();
    } else {
        tabFavorites.classList.add('active');
        tabSearch.classList.remove('active');
        renderFavorites();
    }
}

function renderFavorites() {
    hideError();
    if (favorites.length === 0) {
        mainContent.innerHTML = `
            <div class="grid-banner">Saved Recipes</div>
            <div style="text-align: center; padding: 60px; color: var(--text-secondary);">
                <i class="fa-solid fa-bookmark" style="font-size: 2rem; margin-bottom: 12px; color: var(--border-color);"></i>
                <h2>No saved recipes</h2>
                <p>Bookmark recipes while browsing to save them here.</p>
            </div>
        `;
        return;
    }
    displayRecipes(favorites, "Saved Recipes");
}

function copyIngredients(ingredientsArray) {
    navigator.clipboard.writeText(ingredientsArray.join('\n')).then(() => {
        alert("Ingredients copied to clipboard.");
    });
}

function showLoading(show) {
    loadingEl.classList.toggle('hidden', !show);
}

function showError(message) {
    errorMsgEl.textContent = message;
    errorMsgEl.classList.remove('hidden');
}

function hideError() {
    errorMsgEl.classList.add('hidden');
}